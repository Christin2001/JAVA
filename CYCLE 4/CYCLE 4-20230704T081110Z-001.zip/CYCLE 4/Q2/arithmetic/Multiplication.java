package arithmetic;

public interface Multiplication {
    public double multiply(double num1, double num2);
}

