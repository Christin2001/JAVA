package arithmetic;

public interface Division {
    public double divide(double num1, double num2);
}

