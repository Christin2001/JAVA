package arithmetic;

public interface Subtraction {
    public double subtract(double num1, double num2);
}

