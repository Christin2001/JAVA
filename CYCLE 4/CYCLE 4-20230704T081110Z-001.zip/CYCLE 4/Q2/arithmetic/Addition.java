package arithmetic;

public interface Addition {
    public double add(double num1, double num2);
}

